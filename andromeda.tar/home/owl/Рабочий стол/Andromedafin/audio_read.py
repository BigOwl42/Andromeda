import subprocess

def record_stream(stream_url, output_file, duration):
    """
    Записывает часть потока с использованием FFmpeg.

    Args:
        stream_url (str): URL потока.
        output_file (str): Путь к выходному файлу.
        duration (int): Длительность записи в секундах.
    """
    try:
        command = [
            "ffmpeg",
             "-y",
            "-re",
            "-i",
            stream_url,
            "-t",
            str(duration),
            "-c",
            "copy",
            output_file
        ]
        subprocess.run(command, check=True)
        print(f"Запись в {output_file} завершена успешно.")
    except subprocess.CalledProcessError as e:
        print(f"Произошла ошибка при записи: {e}")

if __name__ == "__main__":
    stream_url = "https://manifest.googlevideo.com/api/manifest/hls_playlist/expire/1740050012/ei/_Lm2Z7rHDdGt0u8P7O_a4AM/ip/188.243.183.231/id/HuFYqnbVbzY.2/itag/234/source/yt_live_broadcast/requiressl/yes/ratebypass/yes/live/1/goi/133/sgoap/gir%3Dyes%3Bitag%3D140/rqh/1/hls_chunk_host/rr2---sn-n3toxu-axqs.googlevideo.com/xpc/EgVo2aDSNQ%3D%3D/playlist_duration/3600/manifest_duration/3600/bui/AUWDL3y3K34hJenVPoOftBnUZRhbpYLbmlFIJ2z_7Mpzun3GwlsuEcWWh0c9oOpVURkZePayIriiwna5/spc/RjZbSRPSSFxliXM_VPsMQJKSoH77jGw1JgABuPkgMWqQ4nZfn58M/vprv/1/playlist_type/DVR/initcwndbps/3110000/met/1740028412,/mh/GY/mm/44/mn/sn-n3toxu-axqs/ms/lva/mv/m/mvi/2/pl/24/rms/lva,lva/dover/13/pacing/0/short_key/1/keepalive/yes/fexp/51326932/mt/1740028111/sparams/expire,ei,ip,id,itag,source,requiressl,ratebypass,live,goi,sgoap,rqh,xpc,playlist_duration,manifest_duration,bui,spc,vprv,playlist_type/sig/AJfQdSswRQIgLIEThji6cbVs9NMBWYUFXdBCexz6Bb9mMvMPfIGqaI4CIQDDwi9RoqUXmQfiM-mZjiwZWngFltyKlD7w3HAYelm_6g%3D%3D/lsparams/hls_chunk_host,initcwndbps,met,mh,mm,mn,ms,mv,mvi,pl,rms/lsig/AGluJ3MwRQIhAN-uc_ValMqFIBI9tBnj6uo6RwfRW_uLeU_9b_6nI9L2AiA3JkR35IgLOFjX0iZ3a4InvX-1-HKDIqpHNv_4HZRX6w%3D%3D/playlist/index.m3u8"
    i=1
    while 1:
            
            output_file = "./audio/audio" + str(i) +".wav"
            duration = 10
            record_stream(stream_url, output_file, duration)
            i=i+1
            if i>10000000000000000000000000:
                 i=1

