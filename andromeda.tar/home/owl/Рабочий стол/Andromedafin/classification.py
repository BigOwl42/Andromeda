import pickle
from telegram import Bot
import asyncio

TOKEN = "7130814683:AAHThiz7YvWUz9xTf9K8VQ_urg_lS7unYJ8"
CHAT_ID = "778402531"

filename_model = './andromeda_model.pkl'
filename_vectorizer = './tfidf_vectorizer.pkl'


loaded_model = pickle.load(open(filename_model, 'rb'))
loaded_vectorizer = pickle.load(open(filename_vectorizer, 'rb'))


async def send_message(text):
    bot = Bot(token=TOKEN)
    await bot.send_message(chat_id=CHAT_ID, text=text)  # Используем await

# Пример использования
async def main():
    i=1
    while 1:
        text_name = "./text/text"+str(i)+".txt"
        try:
            with open(text_name, "r", encoding="utf-8") as f:
                new_text = f.read()  # Читаем весь файл в одну строку
        except:
             continue
        print (new_text)
        new_text_tfidf = loaded_vectorizer.transform([new_text])
        prediction = loaded_model.predict(new_text_tfidf)
        print(f"Предсказание для текста '{new_text[0]}': {prediction[0]}")

        if prediction[0]==1:
            await send_message("Внимание! На МКС происходит что-то необычное! Скорее подключайтесь к трансляции!\n Фрагмент переговоров:  "+new_text)
        i=i+1
        if i>10000000000000000000000000:
                 i=1

    #Если предсказание 1, то должны отправить расшифрованный текст + сообщение об опасности в ТГ бота 

# Запуск программы
if __name__ == "__main__":
    asyncio.run(main())  # Запускаем асинхронный код
