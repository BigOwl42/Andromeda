from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Токен вашего бота
TOKEN = "7130814683:AAHThiz7YvWUz9xTf9K8VQ_urg_lS7unYJ8"
CHAT_ID_FILE = "C:\Data\Study\\7\BOS\Курсач\CHAT_IDS.txt"

def add_chat_id(chat_id):
    """Добавляет chat ID в файл (если его там еще нет)."""
    chat_id = str(chat_id)  # Преобразуем в строку для надежности
    try:
        with open("C:\Data\Study\\7\BOS\Курсач\CHAT_IDS.txt", "r", encoding="utf-8") as f:
            existing_chat_ids = f.read().splitlines()
        if chat_id not in existing_chat_ids:
            with open(CHAT_ID_FILE, "a", encoding="utf-8") as f:
                f.write(chat_id + "\n")
            print(f"Chat ID {chat_id} добавлен.")
    except FileNotFoundError:
        # Если файл не существует, создаем его и добавляем chat ID
        with open(CHAT_ID_FILE, "w", encoding="utf-8") as f:
            f.write(chat_id + "\n")
        print(f"Файл {CHAT_ID_FILE} создан. Chat ID {chat_id} добавлен.")



COMMAND_FILE = "commands.txt"
SLEEP_TIME = 5  # Время между проверками файла (в секундах)


# Обработчик команды /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    add_chat_id(chat_id)
    await update.message.reply_text("Привет! Я бот проекта Андромеда, предназначенный для оповещения человечества о необычных или опасных событифях на МКС")

# Обработчик команды /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Как только в переговорах экипажа МКС с Землёй будет зарегистрированна необычная активность, я пришлю уведомления всем пользователям. К сожалению, функционал для реагирования на ваши сообщения пока не добавлен.")

# Обработчик текстовых сообщений
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    await update.message.reply_text(f"Пока я не умею реагировать на ваши сообщения")

# Обработчик ошибок
async def error(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f"Ошибка: {context.error}")

# Основная функция
def main():
    # Создаем приложение и передаем токен бота
    app = Application.builder().token(TOKEN).build()

    # Регистрируем обработчики команд
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))

    # Регистрируем обработчик текстовых сообщений
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Регистрируем обработчик ошибок
    app.add_error_handler(error)

    # Запускаем бота
    print("Бот запущен...")

    app.run_polling()

# Запуск программы
if __name__ == "__main__":
    main()


