import whisper
import os

path = "C:\\Data\\Study\\7\\BOS\\test1.wav"  # Замените на путь к вашему файлу

if os.path.exists(path):
    print("Файл существует.")
else:
    print("Файл не существует.")
# Загрузка модели Whisper (можно выбрать модель разного размера: tiny, base, small, medium, large)
model = whisper.load_model("base")  # Для начала подойдет "base"
i=3
while 1:
        name = "./audio/audio" + str(i) +".wav"
        text_name = "./text/text"+str(i)+".txt"
# Транскрибация аудиофайла
        audio_path = name  # Путь к вашему аудиофайлу

        try:
            result = model.transcribe(audio_path)
            os.remove(audio_path)
# Вывод результата
            print("Распознанный текст:")
            print(result["text"])
            with open(text_name, "w", encoding="utf-8") as f:
                 f.write(result["text"])
            print("save to file")
            i=i+1
            if i>10000000000000000000000000:
                 i=1
        except:
             print (i, "  waiting...")
             continue
        
